package com.example.a09cinema_backenddevelop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A09cinemaBackendDevelopApplicationTests {

    @Test
    void contextLoads() {
    }

}
