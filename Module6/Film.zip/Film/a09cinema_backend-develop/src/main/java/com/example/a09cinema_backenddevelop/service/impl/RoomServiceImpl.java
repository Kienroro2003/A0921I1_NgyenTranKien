package com.example.a09cinema_backenddevelop.service.impl;

import com.example.a09cinema_backenddevelop.service.RoomService;
import org.springframework.stereotype.Service;

@Service
public class RoomServiceImpl implements RoomService {
}
