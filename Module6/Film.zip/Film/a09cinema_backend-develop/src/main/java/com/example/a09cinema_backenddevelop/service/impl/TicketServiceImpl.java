package com.example.a09cinema_backenddevelop.service.impl;

import com.example.a09cinema_backenddevelop.service.TicketService;
import org.springframework.stereotype.Service;

@Service
public class TicketServiceImpl implements TicketService {
}
