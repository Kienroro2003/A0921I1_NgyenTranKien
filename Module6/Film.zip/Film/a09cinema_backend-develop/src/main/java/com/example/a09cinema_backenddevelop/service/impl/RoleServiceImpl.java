package com.example.a09cinema_backenddevelop.service.impl;

import com.example.a09cinema_backenddevelop.service.RoleService;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {
}
