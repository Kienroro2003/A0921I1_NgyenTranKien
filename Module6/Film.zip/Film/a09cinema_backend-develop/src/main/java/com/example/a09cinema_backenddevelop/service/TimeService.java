package com.example.a09cinema_backenddevelop.service;

public interface TimeService {
}
