package com.example.a09cinema_backenddevelop.repository;

public interface TicketRepository {
}
