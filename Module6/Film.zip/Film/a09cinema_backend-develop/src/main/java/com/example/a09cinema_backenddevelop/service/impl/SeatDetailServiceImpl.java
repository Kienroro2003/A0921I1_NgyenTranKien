package com.example.a09cinema_backenddevelop.service.impl;

import com.example.a09cinema_backenddevelop.service.SeatDetailService;
import org.springframework.stereotype.Service;

@Service
public class SeatDetailServiceImpl implements SeatDetailService {
}
