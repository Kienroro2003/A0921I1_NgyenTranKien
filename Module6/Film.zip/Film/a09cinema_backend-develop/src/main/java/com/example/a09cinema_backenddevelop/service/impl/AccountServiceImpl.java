package com.example.a09cinema_backenddevelop.service.impl;

import org.springframework.stereotype.Service;
import  com.example.a09cinema_backenddevelop.service.AccountService;
@Service
public class AccountServiceImpl implements AccountService {

}
