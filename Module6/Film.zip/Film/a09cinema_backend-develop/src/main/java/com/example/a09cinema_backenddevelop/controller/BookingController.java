package com.example.a09cinema_backenddevelop.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BookingController {
}
