package com.example.a09cinema_backenddevelop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A09cinemaBackendDevelopApplication {

    public static void main(String[] args) {
        SpringApplication.run(A09cinemaBackendDevelopApplication.class, args);
    }

}
